//
//  TabBarController.m
//  MeiTuan
//
//  Created by peter on 2018/6/28.
//  Copyright © 2018年 程光耀. All rights reserved.
//

#import "TabBarController.h"
#import "HomeViewController.h"
#import "ShopViewController.h"
#import "MineViewController.h"
#import "MoreViewController.h"

@interface TabBarController ()

@property (nonatomic, strong) NSArray *allControllers ;
//最近一次选择的Index
@property(assign, nonatomic) NSUInteger lastSelectedIndex;

@end

@implementation TabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = [UIColor whiteColor] ;
    [self setViewControllers:self.allControllers animated:NO];
}

- (NSArray *)allControllers{
    if (_allControllers == nil) {
        HomeViewController *home = [[HomeViewController alloc] init] ;
        ShopViewController *shop = [[ShopViewController alloc] init] ;
        MineViewController *mine = [[MineViewController alloc] init] ;
        MoreViewController *more = [[MoreViewController alloc] init] ;
        
        NSArray *array = @[[self navWithRoot:home title:@"首页" image:@"icon_tabbar_homepage" selectedImage:@"icon_tabbar_homepage_selected"],
                          [self navWithRoot:shop title:@"商家" image:@"icon_tabbar_merchant_normal" selectedImage:@"icon_tabbar_merchant_selected"],
                          [self navWithRoot:mine title:@"我的" image:@"icon_tabbar_mine" selectedImage:@"icon_tabbar_mine_selected"],
                          [self navWithRoot:more title:@"更多" image:@"icon_tabbar_misc" selectedImage:@"icon_tabbar_misc_selected"]];

        
        _allControllers = [[NSArray alloc] initWithArray:array];
    }
    return _allControllers;
}

- (UINavigationController *)navWithRoot:(UIViewController *)vc title:(NSString *)title image:(NSString *)image selectedImage:(NSString *)selectedImage {
    
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
    
    UIImage *imageNormal = [UIImage imageNamed:image];
    UIImage *imageSelected = [UIImage imageNamed:selectedImage];
    
    UITabBarItem *tabBarItem = [[UITabBarItem alloc] initWithTitle:title image:[[imageNormal bp_scaleWithSize:CGSizeMake(30, 30)] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] selectedImage:[[imageSelected bp_scaleWithSize:CGSizeMake(30, 30)] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];

    tabBarItem.titlePositionAdjustment = UIOffsetMake(0, -2) ;
    [tabBarItem setTitleTextAttributes:[NSDictionary dictionaryWithObject:[UIColor orangeColor] forKey:NSForegroundColorAttributeName] forState:UIControlStateSelected] ;
    nav.tabBarItem = tabBarItem ;
    return nav;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
