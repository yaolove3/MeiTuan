//
//  GlobalDefine.h
//  MeiTuan
//
//  Created by peter on 2018/6/28.
//  Copyright © 2018年 程光耀. All rights reserved.
//

#ifndef GlobalDefine_h
#define GlobalDefine_h

//#define HomeJS @"/Users/peter/Desktop/MeiTuan_Weex/JS/home.js"
//#define ShopJS @"/Users/peter/Desktop/MeiTuan_Weex/JS/shop.js"
//#define MineJS @"/Users/peter/Desktop/MeiTuan_Weex/JS/mine.js"
//#define MoreJS @"/Users/peter/Desktop/MeiTuan_Weex/JS/more.js"

#define HomeJS @"/Users/peter/Desktop/weexCode/weexDemo/dist/index.js"
#define ShopJS @"/Users/peter/Desktop/weexCode/weexDemo/dist/index.j"
#define MineJS @"/Users/peter/Desktop/weexCode/weexDemo/dist/index.j"
#define MoreJS @"/Users/peter/Desktop/weexCode/weexDemo/dist/index.j"

#endif /* GlobalDefine_h */
