//
//  UIImage+BPUIKitAddition.h
//  BPUIKit
//
//  Created by yfzx_sh_louwk on 16/8/11.
//  Copyright © 2016年 Mars Lou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (BPUIKitAddition)

- (UIImage *)bp_clipCircleWithBorderWidth:(CGFloat)borderWidth borderColor:(UIColor *)borderColor;

/**
 *  图片加模糊
 *
 *  @param blur 模糊度数
 *
 *  @return 模糊后图片
 */
- (UIImage *)bp_blurryImageWithBlurLevel:(CGFloat)blur;

/**
 *  给出颜色，绘制图片
 *
 *  @param color 图片颜色
 *  @param size  图片尺寸
 *
 *  @return UIImage
 */
+ (UIImage *)bp_imageFromColor:(UIColor *)color size:(CGSize)size;
+ (UIImage *)bp_imageFromColor:(UIColor *)color;

- (UIImage *)bp_scaleWithSize:(CGSize)scaleSize;

- (UIImage *)bp_tintWithColor:(UIColor *)color;
//根据指定大小生成一个平铺的图片
- (UIImage *)bp_spreadImageWithSize:(CGSize)size;
#pragma mark - Base64转码

//compressionQuality 压缩比 0.0~1.0，0.0最大
- (NSString *)bp_imageStringWithCompressionQuality:(CGFloat)compressionQuality;
+ (UIImage *)bp_imageFromString:(NSString *)string;

@end

CG_INLINE UIImage *bp_image_named(NSString *name) {
    return [UIImage imageNamed:name];
}
