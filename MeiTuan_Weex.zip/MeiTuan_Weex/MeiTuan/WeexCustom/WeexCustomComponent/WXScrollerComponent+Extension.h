//
//  WXScrollerComponent+Extension.h
//
//  Created by HJaycee on 2017/8/14.
//

#import <WeexSDK/WeexSDK.h>

/**
 扩展了下拉刷新功能
 */
@interface WXScrollerComponent (Extension)

@end
