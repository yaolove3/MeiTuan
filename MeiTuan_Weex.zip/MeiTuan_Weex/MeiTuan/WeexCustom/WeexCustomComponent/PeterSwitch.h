//
//  PeterSwitch.h
//  MeiTuan
//
//  Created by peter on 2018/7/17.
//  Copyright © 2018年 程光耀. All rights reserved.
//

#import "WXComponent.h"

@interface PeterSwitch : WXComponent

@end
