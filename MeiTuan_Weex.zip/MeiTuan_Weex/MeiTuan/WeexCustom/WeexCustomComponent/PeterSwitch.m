//
//  PeterSwitch.m
//  MeiTuan
//
//  Created by peter on 2018/7/17.
//  Copyright © 2018年 程光耀. All rights reserved.
//

#import "PeterSwitch.h"
@interface PeterSwitch ()

@property (nonatomic, assign) BOOL isOn ;
@property (nonatomic, strong) UIColor *tintColor ;
@property (nonatomic, strong) UIColor *onTintColor ;
@property (nonatomic, strong) UIColor *thumbTintColor ;

@end

@implementation PeterSwitch
- (UIView *)loadView {
    UISwitch *mySwitch = [[UISwitch alloc]init];
    [mySwitch addTarget:self action:@selector(switchAction:) forControlEvents:UIControlEventValueChanged];
    return mySwitch;
}
- (void)viewDidLoad {
    UISwitch *mySwitch = ((UISwitch *)self.view);
    //tintColor 关状态下的背景颜色
    mySwitch.tintColor = _tintColor;
    //onTintColor 开状态下的背景颜色
    mySwitch.onTintColor = _onTintColor;
    //thumbTintColor 滑块的背景颜色
    mySwitch.thumbTintColor = _thumbTintColor;
    
    mySwitch.on = _isOn;
}
//- (void)addEvent:(NSString *)eventName {
//    if ([eventName isEqualToString:@"onSwitch"]) {
//
//    }
//}
//- (void)removeEvent:(NSString *)eventName
//{
//    if ([eventName isEqualToString:@"onSwitch"]) {
//
//    }
//}
- (void)switchAction:(UISwitch *)mySwitch{
    [self fireEvent:@"onSwitch" params:@{@"isSwitchOn":@(mySwitch.isOn)} domChanges:nil];
}

- (instancetype)initWithRef:(NSString *)ref type:(NSString *)type styles:(NSDictionary *)styles attributes:(NSDictionary *)attributes events:(NSArray *)events weexInstance:(WXSDKInstance *)weexInstance {
    if(self = [super initWithRef:ref type:type styles:styles attributes:attributes events:events weexInstance:weexInstance]) {
        
        if (attributes[@"tintColor"]) {
            _tintColor = [WXConvert UIColor:attributes[@"tintColor"]];
        }
        if (attributes[@"onTintColor"]) {
            _onTintColor = [WXConvert UIColor:attributes[@"onTintColor"]];
        }
        if (attributes[@"thumbTintColor"]) {
            _thumbTintColor = [WXConvert UIColor:attributes[@"thumbTintColor"]];
        }
        if (attributes[@"isOn"]) {
            _isOn = [WXConvert BOOL:attributes[@"isOn"]];
        }
    }
    return self;
}
- (void)updateAttributes:(NSDictionary *)attributes
{
    if (attributes[@"tintColor"]) {
        _tintColor = [WXConvert UIColor:attributes[@"tintColor"]];
        ((UISwitch *)self.view).tintColor = _tintColor;
    }
    if (attributes[@"onTintColor"]) {
        _onTintColor = [WXConvert UIColor:attributes[@"onTintColor"]];
        ((UISwitch *)self.view).onTintColor = _onTintColor;
    }
    if (attributes[@"thumbTintColor"]) {
        _thumbTintColor = [WXConvert UIColor:attributes[@"thumbTintColor"]];
        ((UISwitch *)self.view).thumbTintColor = _thumbTintColor;
    }
    if (attributes[@"isOn"]) {
        _isOn = [WXConvert BOOL:attributes[@"isOn"]];
        ((UISwitch *)self.view).on = _isOn;
    }
}
@end
